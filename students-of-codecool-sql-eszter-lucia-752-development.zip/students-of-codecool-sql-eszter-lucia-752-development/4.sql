UPDATE evaluation
set grade = 3,
modules_id = 14
where id = 5;

select *
from evaluation
where id=5;