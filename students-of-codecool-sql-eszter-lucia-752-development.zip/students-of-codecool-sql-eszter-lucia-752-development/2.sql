CREATE TABLE students(
    id serial primary key,
    name varchar(50),
    github_account varchar(50),
    email varchar(50),
    hobby varchar(50),
    date_of_birth date,
);

CREATE TABLE courses(
    id serial primary key,
    name varchar(30),
    date_of_start date,
    mentor varchar(35)
);

CREATE TABLE students_and_courses(
    id serial primary key,
    students_id integer not null,
    courses_id integer not null
);

CREATE TABLE courses_and_modules(
    id serial primary key,
    courses_id integer not null,
    modules_id integer not null
);

CREATE TABLE modules(
    id serial primary key,
    category varchar(50),
    title varchar(30),
    description text,
    is_Team boolean
);

CREATE TABLE background_materials(
    id int primary key,
    modules_id integer not null,
    link text
);

CREATE TABLE tasks(
    id int primary key,
    modules_id integer not null,
    title text,
    description text
);

CREATE TABLE evaluation(
    id serial primary key,
    students_id integer not null,
    modules_id integer not null,
    grade integer,
    reviewer int,
    courses_id integer not null
);

