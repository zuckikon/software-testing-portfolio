-- 1
-- Assignments are listed by courses

SELECT courses.name, modules.title
FROM courses
JOIN courses_and_modules ON courses_id = courses.id
JOIN modules on modules.id = modules_id;

-- 2
-- Assignments with all related elements are listed

SELECT category, modules.title, modules.description, is_team, courses.name, courses.mentor, tasks.title, background_materials.link
FROM modules
JOIN courses_and_modules ON modules_id = modules.id
JOIN courses ON courses_id = courses.id
JOIN tasks ON tasks.modules_id = modules.id
JOIN background_materials ON modules.id = background_materials.modules_id;

-- 3
-- Students are listed by courses

SELECT students.name, github_account, string_agg(courses.name::text, ', ') as courses_name
FROM students
JOIN students_and_courses ON students.id = students_and_courses.students_id
JOIN courses ON courses_id = courses.id
GROUP BY students.id;

-- 4
-- The students' evaluations per assignments, based on their results, including all the details of the evaluation

SELECT ev.id,
 s.name as student,
 ev.grade,
 c.name as course,
 r.name as reviewer,
 m.category,
 m.title
FROM students s
JOIN evaluation ev on ev.students_id = s.id
JOIN students r on ev.reviewer = r.id
JOIN modules m on ev.modules_id = m.id
JOIN courses c on ev.courses_id = c.id
ORDER BY s.name;


-- 5
-- Aggregated result of the students' performance.
-- The query should calculate an average of the scores achieved and if the student scored above 60%,
-- he would receive an "advanced" rating, if below, he would be "considered advanced".

select students.name, round(avg(evaluation.grade)) as average_grade, 
(CASE
    WHEN avg((evaluation.grade)/5)*100 > 60
        THEN 'advanced'
    ELSE 'considered advanced' END)
    as rating
from students
JOIN evaluation ON students_id = students.id
GROUP BY students.name;

-- 6
--List of the 3 best performing students based on their scores.

SELECT students.id, students.name, grade
FROM students
JOIN evaluation ON students_id = students.id
ORDER BY evaluation.grade DESC
LIMIT 3;

-- 7
-- Anything you think is important is added.
-- How many people registered for the courses?

SELECT courses.name, date_of_start, mentor, count(students.id) as number_of_students
FROM courses
JOIN students_and_courses ON courses_id = courses.id
JOIN students ON students_id = students.id
GROUP BY courses.id