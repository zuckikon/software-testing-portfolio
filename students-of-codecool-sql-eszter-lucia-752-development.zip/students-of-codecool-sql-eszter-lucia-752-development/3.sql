INSERT INTO students
VALUES
(default,'Balla Ákos','Akos-stack-create','mandarinpauul@gmail.com', 'soccer', '1996.01.01'),
(default,'Kovács Eszter', 'zuckikon', 'kovacseszter.2002@gmail.com', 'videogame', '2002.04.09'),
(default,'Nagyné Muri Emese', 'muriemese-44','muriemese@gmail.com', 'photography', '1995.04.04'),
(default,'Papné Molnár Lucia', 'pmlucia1991','pm.lucia1991@gmail.com', 'reading', '1991.02.12'),
(default,' Sárvári Barnabás', 'Bar-Na', 'abarnus96@gmail.com', 'sport', '1996.06.01');

INSERT INTO courses
VALUES
(default, 'Manual Tester', '2025.10.20', 'Lenner Tamás'),
(default, 'Full-stack Developer', '2025.03.17', 'Nyilas Gábor'),
(default, 'Frontend Developer', '2025.11.30', 'Kohányi Róbert'),
(default, 'Data Analyst', '2026.01.12', 'Lenner Tamás');

INSERT INTO students_and_courses
VALUES
(default,1,1),
(default,2,1),
(default,3,1),
(default,4,1),
(default,5,1),
(default,1,2),
(default,3,4),
(default,2,4);

INSERT INTO evaluation
VALUES
(default,3,2,3,1,1),
(default,4,3,5,2,1),
(default,1,1,4,5,1),
(default,5,2,5,4,1),
(default,2,2,2,3,4);

INSERT INTO modules
VALUES
(default,'From scratch','Git started','All projects in Codecool are handled using Git, and this project covers the necessary basics of Git usage.', 'False'),
(default, 'Linux','Everything is a File','After getting a nervous breakdown due to the stress being a system administrator you went into exile to a monastery on top of a mountain in Silicon Valley.', 'False'),
(default, 'SQL','TodoDB.sql', 'Todo app is an upcoming, lightweight program with which multiple users can track their todos simultaneously', 'False'),
(default,'SQL', 'Students of Codecool','Create a database for Codecool students, in which you can store the data necessary for learning.', 'True'),
(default,'JavaScript', 'HTML and CSS', 'You will be the master on the advanced level', 'False');


INSERT INTO courses_and_modules
VALUES
(default,1,1),
(default,1,2),
(default,1,3),
(default,1,4),
(default,2,5);

INSERT INTO tasks
VALUES
(11, 2,'Virtual Disk','Create or use an existing, an ext4 formatted virtual disk (.vdi), attach it to your VM and mount it.'),
(3, 1, 'Create GitHub repository','Click the Start Project button at the top right of the page to create your project repository. Then click the Open repository button to navigate to a GitHub repository page.'),
(37, 4, 'ER diagram', 'Creating an Entity Relationship Diagram (ERD) involves visually mapping out the structure of a database by identifying the entities (tables) and their relationships.'),
(25, 3, 'Create Database', 'Create an empty database on your database server and connect to it');

INSERT INTO background_materials
VALUES
(33,4,'https://www.w3schools.com/sql/'),
(6,1,'https://journey.study/v3/learn/materials/tutorials/git-ssh-setup.md'),
(12,3,'https://www.postgresqltutorial.com/postgresql-primary-key/');